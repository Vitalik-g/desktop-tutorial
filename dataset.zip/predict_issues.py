import torch
from transformers import BertTokenizerFast, BertForTokenClassification
import json

# Завантаження моделі та токенізатора
model_path = "./bio_issue_model"
tokenizer = BertTokenizerFast.from_pretrained(model_path)
model = BertForTokenClassification.from_pretrained(model_path)

# Список міток
label_list = ["B-ISSUE", "I-ISSUE", "B-NON", "I-NON"]
id2label = {i: label for i, label in enumerate(label_list)}

def predict_issues(messages):
    """
    Функція для передбачення груп повідомлень та їх класифікації
    
    Args:
        messages (list): Список повідомлень для аналізу
        
    Returns:
        list: Список груп повідомлень з їх класифікацією
    """
    # Токенізація вхідних повідомлень
    inputs = tokenizer(
        messages,
        truncation=True,
        padding="max_length",
        is_split_into_words=True,
        return_tensors="pt",
        max_length=128
    )
    
    # Отримання передбачень
    with torch.no_grad():
        outputs = model(**inputs)
        predictions = outputs.logits.argmax(dim=-1)
    
    # Обробка передбачень
    word_ids = inputs.word_ids(batch_index=0)
    current_group = []
    groups = []
    current_issue = None
    
    for idx, (word_idx, pred) in enumerate(zip(word_ids, predictions[0])):
        if word_idx is None:
            continue
            
        label = id2label[pred.item()]
        
        if label.startswith("B-"):
            # Якщо вже є група, зберігаємо її
            if current_group:
                groups.append({
                    "issue": current_issue,
                    "messages": current_group
                })
            
            # Починаємо нову групу
            current_group = [messages[word_idx]]
            current_issue = label == "B-ISSUE"
            
        elif label.startswith("I-"):
            current_group.append(messages[word_idx])
    
    # Додаємо останню групу
    if current_group:
        groups.append({
            "issue": current_issue,
            "messages": current_group
        })
    
    return groups

def process_input_file(input_file, output_file):
    """
    Обробка вхідного файлу з повідомленнями та збереження результатів
    
    Args:
        input_file (str): Шлях до вхідного JSON файлу
        output_file (str): Шлях до вихідного JSON файлу
    """
    # Завантаження вхідних даних
    with open(input_file, 'r', encoding='utf-8') as f:
        data = json.load(f)
    
    results = []
    for item in data:
        # Отримання передбачень для кожного набору повідомлень
        output = predict_issues(item["input"])
        
        # Формування результату
        result = {
            "input": item["input"],
            "output": output
        }
        results.append(result)
    
    # Збереження результатів
    with open(output_file, 'w', encoding='utf-8') as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

if __name__ == "__main__":
    # Приклад використання
    test_messages = [
        "Дякую, все працює!",
        "Гарного дня!",
        "Сторінка зависає при завантаженні.",
        "Очікування понад 30 секунд.",
        "Пробував у різних браузерах.",
        "Знайшов рішення, дякую за підтримку."
    ]
    
    # Тестування на одиночному наборі повідомлень
    result = predict_issues(test_messages)
    print("Результат для тестових повідомлень:")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    
    # Обробка вхідного файлу (розкоментуйте, якщо потрібно)
    # process_input_file("input.json", "output.json") 