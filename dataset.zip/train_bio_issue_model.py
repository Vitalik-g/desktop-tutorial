import json
from datasets import Dataset
from transformers import BertTokenizerFast, BertForTokenClassification, Trainer, TrainingArguments, DataCollatorForTokenClassification
import torch
import transformers
print(transformers.__version__)
# === 1. Список міток ===
label_list = ["B-ISSUE", "I-ISSUE", "B-NON", "I-NON"]
label2id = {label: i for i, label in enumerate(label_list)}
id2label = {i: label for label, i in label2id.items()}

# === 2. Завантаження даних у BIO-форматі ===
def load_dataset_bio_format(path):
    with open(path, "r", encoding="utf-8") as f:
        raw = json.load(f)

    examples = []
    for item_index, item in enumerate(raw):
        input_msgs = item["input"]
        label_tags = [""] * len(input_msgs)

        for group in item["output"]:
            issue = group["issue"]
            tag = "ISSUE" if issue else "NON"
            msgs = group["messages"]

            # Знайти, де ця група починається в input
            idx_start = None
            for i in range(len(input_msgs) - len(msgs) + 1):
                if input_msgs[i:i+len(msgs)] == msgs:
                    idx_start = i
                    break
            if idx_start is None:
                raise ValueError(f"[Запис #{item_index}] Не знайдено групу повідомлень у input:\n{msgs}\n---\n{input_msgs}")

            label_tags[idx_start] = f"B-{tag}"
            for j in range(1, len(msgs)):
                label_tags[idx_start + j] = f"I-{tag}"

        # Позначити всі непозначені повідомлення як NON
        for i, tag in enumerate(label_tags):
            if tag == "":
                label_tags[i] = "B-NON" if (i == 0 or label_tags[i - 1] != "I-NON") else "I-NON"

        examples.append({
            "messages": input_msgs,
            "labels": [label2id[label] for label in label_tags]
        })

    return Dataset.from_list(examples)

# === 3. Токенізація та вирівнювання міток ===
tokenizer = BertTokenizerFast.from_pretrained("bert-base-multilingual-cased")

def tokenize_and_align_labels(example):
    tokenized = tokenizer(
        example["messages"], 
        truncation=True, 
        padding="max_length", 
        is_split_into_words=True, 
        max_length=128
    )
    
    labels = []
    word_ids = tokenized.word_ids(batch_index=0)
    previous_word_idx = None
    
    for word_idx in word_ids:
        if word_idx is None:
            labels.append(-100)  # Для токенів, яких немає, використовуємо -100
        elif word_idx != previous_word_idx:
            labels.append(example["labels"][word_idx])  # Встановлюємо мітки для нових слів
        else:
            labels.append(example["labels"][word_idx])  # Для однакових слів залишаємо ті ж мітки
        previous_word_idx = word_idx
    
    tokenized["labels"] = labels
    return tokenized

# === 4. Завантаження та підготовка даних ===
dataset = load_dataset_bio_format("dataset.json")
dataset = dataset.map(tokenize_and_align_labels, batched=False)

# Розділення на тренувальний та валідаційний набори
dataset = dataset.train_test_split(test_size=0.2, seed=42)
train_dataset = dataset["train"]
val_dataset = dataset["test"]

# === 5. Модель ===
model = BertForTokenClassification.from_pretrained(
    "bert-base-multilingual-cased",
    num_labels=len(label_list),
    id2label=id2label,
    label2id=label2id
)

# === 6. Параметри тренування ===
args = TrainingArguments(
    output_dir="./bio_issue_model",
    per_device_train_batch_size=4,
    per_device_eval_batch_size=4,
    num_train_epochs=5,
    save_steps=500,
    logging_steps=20,
    logging_dir="./logs",
    save_total_limit=2,
    no_cuda=False,
    overwrite_output_dir=True,
    do_eval=True,
)

data_collator = DataCollatorForTokenClassification(tokenizer)

trainer = Trainer(
    model=model,
    args=args,
    train_dataset=train_dataset,
    eval_dataset=val_dataset,
    tokenizer=tokenizer,
    data_collator=data_collator,
)

# === 7. Навчання ===
trainer.train()

# === 8. Збереження ===
trainer.save_model("./bio_issue_model")
tokenizer.save_pretrained("./bio_issue_model")

# === 9. Функція для передбачення ===
def predict_issues(messages):
    # Токенізація вхідних повідомлень
    inputs = tokenizer(
        messages,
        truncation=True,
        padding="max_length",
        is_split_into_words=True,
        return_tensors="pt",
        max_length=128
    )
    
    # Отримання передбачень
    with torch.no_grad():
        outputs = model(**inputs)
        predictions = outputs.logits.argmax(dim=-1)
    
    # Обробка передбачень
    word_ids = inputs.word_ids(batch_index=0)
    current_group = []
    groups = []
    current_issue = None
    
    for idx, (word_idx, pred) in enumerate(zip(word_ids, predictions[0])):
        if word_idx is None:
            continue
            
        label = id2label[pred.item()]
        
        if label.startswith("B-"):
            # Якщо вже є група, зберігаємо її
            if current_group:
                groups.append({
                    "issue": current_issue,
                    "messages": current_group
                })
            
            # Починаємо нову групу
            current_group = [messages[word_idx]]
            current_issue = label == "B-ISSUE"
            
        elif label.startswith("I-"):
            current_group.append(messages[word_idx])
    
    # Додаємо останню групу
    if current_group:
        groups.append({
            "issue": current_issue,
            "messages": current_group
        })
    
    return groups

print(transformers.__version__)
